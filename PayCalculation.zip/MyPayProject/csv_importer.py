from typing import List  # The List module allows for the use of a specialised type of List
from pay_record import ResidentPayRecord, WorkingHolidayPayRecord  # The pay record classes imported here are used to
# create pay record lists and dictionaries based on employee type


def import_pay_records(file) -> List:
    """import_pay_records function imports a csv file from import folder, reads the data and then arranges the data
    into lists and dictionaries for further processing."""
    payrecord: List = []
    """import_pay_records returns a List[payrecord]"""

    with open(file) as f:
        f.seek(0)
        next(f)
        """Opens file, seeks the start of data and then skips first line"""

        records = f.readlines()
        hours_d = {}
        rates_d = {}
        visa_d = {}
        yeartodate_d = {}
        """f.readlines() reads the rest of the data in file. Dictionaries are created to help process data."""

        for line in records:
            cols = line.split(',')
            id = int(cols[0])
            hours = float(cols[1])
            rates = float(cols[2])
            visa = str(cols[3])
            year_to_date = str(cols[4])
            """line.split(','), splits data separated by comma. Data is then stored in 5 lists of various data types"""

            if id in hours_d.keys():
                hours_d[id].append(hours)
            else:
                hours_d[id] = [hours]

            if id in rates_d.keys():
                rates_d[id].append(rates)
            else:
                rates_d[id] = [rates]

            if id in visa_d.keys():
                visa_d[id].append(visa)
            else:
                visa_d[id] = [visa]

            if id in yeartodate_d.keys():
                yeartodate_d[id].append(year_to_date)
            else:
                yeartodate_d[id] = [year_to_date]
            """For each ID, dictionaries and lists are appended based on their dictionary keys"""

        for id in hours_d.keys():
            recordpay = _create_pay_record(id, hours_d[id], rates_d[id], visa_d[id], yeartodate_d[id])
            payrecord.append(recordpay)
        """Appends the returned List[payrecord] based on the data returned by _create_pay_record function."""

    return payrecord


def _create_pay_record(id, hours, rates, visa, year_to_date):
    """If the visa list does not contain a value, this function will return id, hours and rates data to the
    ResidentPayRecord class, else it will return id, hours, rates, visa and year_to_date data to the
    WorkingHolidayPayRecord class."""
    if visa[0] == "":
        return ResidentPayRecord(id, hours, rates)
    else:
        return WorkingHolidayPayRecord(id, hours, rates, visa[0], year_to_date[0])
