from datetime import datetime  # Imports datetime from datetime module for the purpose of amending time and date to
# exported csv filename


def write_summary(data, to_console=False) -> None:
    """write_summary function serves to export a csv file to the export folder with a timestamp. The csv file will be
    written using get_details method from pay_record module and import_pay_records function from the csv_importer
    module. data parameter is used to import the data from csv_importer. to_console boolean is set to False.
    If to_console parameter is changed to True when calling function, write_summary will print payrecord.get_details()
    to console."""
    timestr = datetime.now().strftime("%Y%m%d-%H%M")
    filename = timestr+"-records.csv"

    with open("export/"+filename, "w") as file:
        for payrecord in data:
            file.write(payrecord.get_details())
            if to_console == bool(True):
                print(payrecord.get_details())
            """For each payrecord in the imported csv data, write to file with payrecord.get_details. If to_console
            boolean is set to True, print to console."""
