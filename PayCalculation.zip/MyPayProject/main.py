import csv_importer
import pay_record_writer


def main():
    import_data = csv_importer.import_pay_records("import/employee-payroll-data.csv")

    pay_record_writer.write_summary(import_data, True)


if __name__ == '__main__':
    main()
