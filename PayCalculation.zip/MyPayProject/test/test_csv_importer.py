import unittest
import csv_importer


class CsvImportTest(unittest.TestCase):
    def setUp(self) -> None:
        self.import_data = csv_importer.import_pay_records("import/employee-payroll-data.csv")

    def test_import_data(self) -> None:
        self.assertEqual(len(self.import_data), 5, "There should be 5 pay records")


if __name__ == '__main__':
    unittest.main()
