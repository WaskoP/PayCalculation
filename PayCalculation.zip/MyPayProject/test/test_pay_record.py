import unittest
import pay_record


class PayRecordTest(unittest.TestCase):
    def setUp(self) -> None:
        self.residentPayClass = pay_record.ResidentPayRecord(1, [2, 3, 3, 4, 5, 6], [25, 25, 25, 25, 32, 32])
        self.workingHolPayClass = pay_record.WorkingHolidayPayRecord(2, [2, 2, 2, 2, 2, 2, 2, 2], [25, 25, 25, 25, 25,
                                                                                                   28, 28, 28],
                                                                     str(417), 47520)

    def test_gross(self) -> None:
        self.assertEqual(self.residentPayClass.gross, 652, "The gross should be $652.00")
        self.assertEqual(self.workingHolPayClass.gross, 418, "The gross should be $418.00")

    def test_tax(self) -> None:
        self.assertEqual(self.residentPayClass.tax, 182.4528, "The tax should be $182.4528.")
        self.assertEqual(self.workingHolPayClass.tax, 133.76, "The tax should be $133.76.")

    def test_net(self) -> None:
        self.assertEqual(self.residentPayClass.net, 469.5472, "The net amount should be 469.5472")
        self.assertEqual(self.workingHolPayClass.net, 284.24, "The net amount should be $284.24")


if __name__ == '__main__':
    unittest.main()
