import unittest
import tax_calculator


class TaxCalculatorTest(unittest.TestCase):
    def setUp(self) -> None:
        self.calculateResTax = tax_calculator.cal_res_tax(652)
        self.calculateWhTax = tax_calculator.cal_wh_tax(418, 47938)

    def test_cal_res_tax(self) -> None:
        self.assertEqual(self.calculateResTax, 182.4528, "The tax amount should equal $182.4528")

    def test_cal_wh_tax(self) -> None:
        self.assertEqual(self.calculateWhTax, 133.76, "The tax amount should equal $133.76")


if __name__ == '__main__':
    unittest.main()
