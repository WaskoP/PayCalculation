import unittest
import pay_record_writer
import csv_importer
from os import path
from datetime import datetime


class PayRecordWriterTest(unittest.TestCase):
    def setUp(self) -> None:
        self.import_data = csv_importer.import_pay_records("import/employee-payroll-data.csv")

    def test_write_summary(self) -> None:
        pay_record_writer.write_summary(self.import_data)
        written = str(path.exists("export/" + datetime.now().strftime("%Y%m%d-%H%M") + "-records.csv"))
        self.assertEqual(written, 'True')


if __name__ == '__main__':
    unittest.main()
