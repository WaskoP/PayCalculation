from typing import List  # The List module allows for the use of a specialised type of List
from abc import ABC, abstractmethod  # ABC and abstractmethod modules help creating classes which use inheritance
from tax_calculator import cal_res_tax, cal_wh_tax  # The classes in this module will rely on tax calculation module


class PayRecord(ABC):
    """Parent class PayRecord will be used as a template for resident and working holiday, employee classes.
    The parent class will always require id, hours and rates parameters and gross, id, tax, net and get_details
    methods from the child classes."""
    def __init__(self, x: int, y: List[float], z: List[float]):
        self._id = x
        self._hours = y
        self._rates = z

    @property
    def gross(self) -> float:
        """gross method returns a List[float] with gross pay. This is calculated by multiplying hours by rates.
        Getter property."""
        gross_list: List[float] = []
        for y, z in zip(self._hours, self._rates):
            value = float(y) * float(z)
            gross_list.append(value)
        return sum(gross_list)

    @property
    def id(self) -> int:
        """id method simply returns id with int type hint. Getter property."""
        return self._id

    @property
    @abstractmethod
    def tax(self) -> float:
        """tax method uses the @abstractmethod property and must be overwritten by child classes."""
        pass

    @property
    def net(self) -> float:
        """net method returns a float based on subtracting self.tax from self.gross. Getter property."""
        net = self.gross - self.tax
        return net

    def get_details(self) -> str:
        """get_details method does not return anything in the parent PayRecord class. Just used the string type hint
        for further child classes."""
        pass


class ResidentPayRecord(PayRecord):
    """ResidentPayRecord class is a child class of PayRecord as seen inside the parenthesis. Super() is used to
    override initializer parameters from the parent class."""
    def __init__(self, id: int, hours: List[float], rates: List[float]):
        super().__init__(id, hours, rates)

    @property
    def tax(self) -> float:
        """tax method overrides the tax method from parent class and includes a function to calculate resident
        tax from the tax_calculator module. Returns a tax_value as a float. Getter property."""
        tax_value = cal_res_tax(self.gross)
        return tax_value

    def get_details(self) -> str:
        """get_details method overrides get_details method from parent class and can be called to return ID, Gross,
        Net and Tax data with some formatting."""
        return 'ID: ' + str(self.id) + \
               '\n Gross: ' + f'{self.gross:.2f}' +\
               '\n Net: ' + f'{self.net:.2f}' +\
               '\n Tax: ' + f'{self.tax:.2f}' + "\n"


class WorkingHolidayPayRecord(PayRecord):
    """WorkingHolidayPayRecord class is a child class of PayRecord as seen inside the parenthesis. Super() is used to
    override initializer parameters from the parent class. The visa and year_to_date initializer parameters are also
    introduced."""
    def __init__(self, id: int, hours: List[float], rates: List[float], visa: str, year_to_date: float):
        super().__init__(id, hours, rates)
        self._visa = visa
        self._year_to_date = year_to_date

    @property
    def visa(self) -> str:
        """visa method returns self._visa as a string value. Getter property."""
        return self._visa

    @property
    def year_to_date(self) -> float:
        """year_to_date method returns self._year_to_date as a float value. Getter property."""
        return self._year_to_date

    @property
    def tax(self) -> float:
        """tax method overrides tax method from parent class and includes a function function to calculate working
        holiday tax from the tax_calculator module. Returns a tax_value as a float. Getter property."""
        tax_value = cal_wh_tax(self.gross, self.year_to_date)
        return tax_value

    def get_details(self) -> str:
        """get_details method overrides get_details method from parent class and can be called to return ID, Gross,
        Net and Tax data with some formatting."""
        return 'ID: ' + str(self.id) + \
               '\n Gross: ' + f'{self.gross:.2f}' +\
               '\n Net: ' + f'{self.net:.2f}' +\
               '\n Tax: ' + f'{self.tax:.2f}' + "\n"
