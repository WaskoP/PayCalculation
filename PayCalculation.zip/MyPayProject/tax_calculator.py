

def cal_res_tax(x: float) -> float:
    """cal_res_tax function returns a tax amount. Tax is calculated from a gross amount which is passed as an argument
    into the cal_res_tax function."""
    gross = x
    if -1 < gross <= 72:
        a = 0.19
        b = 0.19

    elif 72 < gross <= 361:
        a = 0.2342
        b = 3.213

    elif 361 < gross <= 932:
        a = 0.3477
        b = 44.2476

    elif 932 < gross <= 1380:
        a = 0.345
        b = 41.7311

    elif 1380 < gross <= 3111:
        a = 0.39
        b = 103.8657

    elif 3111 < gross <= 999999:
        a = 0.47
        b = 352.7888

    tax = a * gross - b

    return tax


def cal_wh_tax(x: float, y: float) -> float:
    """cal_wh_tax function returns a tax amount. Tax = gross * rate in this function. To calculate rate the function
    requires gross and year_to_date arguments to be passed into the function."""
    gross = x
    year_to_date = y
    total_gross = float(gross) + float(year_to_date)

    if -1 < total_gross <= 37000:
        rate = 0.15

    elif 37000 < total_gross <= 90000:
        rate = 0.32

    elif 90000 < total_gross <= 180000:
        rate = 0.37

    elif 180000 < total_gross <= 9999999:
        rate = 0.45

    tax = gross * rate

    return tax
