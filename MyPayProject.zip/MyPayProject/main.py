import csv
from datetime import datetime
import time

def main():
    city = input("enter word")
    csv_file = csv.reader(open(r"import\employee-payroll-data.csv", "r"))

    for row in csv_file:
        if city == row[1]:
            print(row)


timestr = datetime.now().strftime("%Y%m%d-%H%M%S")
print(timestr)
file_name = "epdata"+timestr+".csv"
print(file_name)
f = open(file_name, "w")
timestr1 = time.strftime("%Y%m%d-%H%M%S")
print(timestr1)
file_name1 = "epdata2"+timestr+".csv"
print(file_name1)
f = open(file_name1, "w")


if __name__ == '__main__':
    main()
