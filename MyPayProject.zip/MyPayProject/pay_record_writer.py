from datetime import datetime
import csv
from csv_importer import import_pay_records
from typing import List
from pay_record import PayRecord


def write_summary():
    timestr = datetime.now().strftime("%Y%m%d-%H%M")
    filename = timestr+"-records.csv"
    with open("export/"+filename, "w") as file:
        records = import_pay_records()
        csvwriter = csv.writer(file)
        csvwriter.writerows(records)
        to_console = bool(False)
        if to_console == bool(True):
            print(records)

    # file: str
    # records: List[PayRecord]
    # to_console: bool(False)
    # return None

write_summary()
