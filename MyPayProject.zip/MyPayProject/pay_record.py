from typing import List
from abc import ABC, abstractmethod
from tax_calculator import cal_res_tax, cal_wh_tax


class PayRecord(ABC):
    def __init__(self, x: int, y: List[float], z: List[float]):
        self._id = x
        self._hours = y
        self._rates = z

    @property
    def gross(self):
        gross_list = []
        for y, z in zip(self._hours, self._rates):
            value = y * z
            gross_list.append(value)
        return sum(gross_list)

    @property
    def id(self):
        return int

    @property
    @abstractmethod
    def tax(self) -> float:
        pass

    @property
    def net(self) -> float:
        net = self.gross - self.tax
        return net

    def get_details(self) -> str:
        pass


class ResidentPayRecord(PayRecord):
    def __init__(self, id: int, hours: List[float], rates: List[float]):
        super().__init__(id, hours, rates)

    @property
    def tax(self) -> float:
        tax_value = cal_res_tax(self.gross)
        return tax_value

    def get_details(self) -> str:
        return 'ID: ' + str(self.id) + \
               '\n Gross: ' + f'{self.gross:.2f}' +\
               '\n Net: ' + f'{self.net:.2f}' +\
               '\n Tax: ' + f'{self.tax:.2f}'


class WorkingHolidayPayRecord(PayRecord):
    def __init__(self, id: int, hours: List[float], rates: List[float], visa: str, year_to_date: float):
        super().__init__(id, hours, rates)
        self._visa = visa
        self._year_to_date = year_to_date

    @property
    def visa(self) -> str:
        visa_value = ""
        return visa_value

    @property
    def year_to_date(self) -> float:
        ytd_value = 0.0
        return ytd_value

    @property
    def tax(self) -> float:
        tax_value = cal_wh_tax(self.gross, self.year_to_date)
        return tax_value

    def get_details(self):
        return 'ID: ' + str(self.id) + \
               '\n Visa: ' + f'{self.visa:.2f}' + \
               '\n Year_to_Date: ' + f'{self.year_to_date:.2f}' +\
               '\n Gross: ' + f'{self.gross:.2f}' +\
               '\n Net: ' + f'{self.net:.2f}' +\
               '\n Tax: ' + f'{self.tax:.2f}'
